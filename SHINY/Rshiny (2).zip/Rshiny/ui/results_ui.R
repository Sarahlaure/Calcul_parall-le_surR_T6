
results_ui <- function() {
  div(
    class = "custom-panel",
    
    h1("Résultats et Visualisation", class = "main-title"),
    h4("Carte du trajet maximal", class = "sub-title"),
    
    leafletOutput("map", height = "500px"),
    
    br(), br(),
    
    h4("Résumé du trajet", class = "sub-title"),
    verbatimTextOutput("summary")
  )
}
