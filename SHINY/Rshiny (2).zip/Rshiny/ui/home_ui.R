
home_ui <- function() {
  div(
    class = "custom-panel",
    h1("PROJET : CALCUL PARALLÈLE SUR DONNÉES AIS", class = "main-title"),
    br(),
    
    h4("Contexte et Objectifs", class = "sub-title"),
    p("Ce projet a pour objectif de développer une application interactive basée sur R Shiny, capable de traiter une base de données AIS volumineuse (plus de 3 millions d’observations) à travers le calcul parallèle."),
    br(),
    
    h4("Fonctionnalités Clés de l’Application", class = "sub-title"),
    tags$ul(
      tags$li("Interface interactive segmentée en onglets."),
      tags$li("Filtres dynamiques sur les types et noms de navires."),
      tags$li("Carte Leaflet pour visualiser les points de départ et d’arrivée."),
      tags$li("Choix du nombre de threads pour le traitement parallèle."),
      tags$li("Affichage des performances : durée, vitesse, nombre de cœurs."),
      tags$li("Déploiement sur shinyapps.io & code source publié sur GitHub.")
    ),
    br(),
    
    h4("Avantages du Calcul Parallèle", class = "sub-title"),
    tags$ul(
      tags$li("Réduction drastique du temps de calcul pour les grandes bases de données."),
      tags$li("Exécution simultanée de plusieurs tâches (calculs par navire)."),
      tags$li("Exploitation optimale des ressources matérielles (multi-cœurs)."),
      tags$li("Amélioration de la réactivité de l’application.")
    ),
    br(),
  
    downloadButton("doc_button", "\U0001F4C4 Télécharger la documentation", class = "btn-primary")
      )
}
