
ships_data <- read.csv("../ships/ships.csv")

param_ui <- function(ships_data) {
  div(
    class = "custom-panel",
    
    h1("Paramétrage et Sélection", class = "main-title"),
    h4("Sélectionnez un type de navire et un navire spécifique", class = "sub-title"),
    
    # Sélection du type de navire
    selectInput("ship_type", "Type de Navire :",
                choices = unique(ships_data$ship_type)),
    
    # Sélection dynamique du navire en fonction du type choisi
    uiOutput("ship_selector"),
    
    br(),
    
    # Afficher les cœurs disponibles
    textOutput("core_info"),
    
    br(),
    
    # Slider pour choisir le nombre de threads
    sliderInput("n_threads", "Nombre de threads à utiliser :",
                min = 1, max = detectCores(), value = 2),
    
    br(),
    
    # Bouton pour lancer l’analyse
    actionButton("run_analysis", "Lancer l’analyse", class = "btn-primary")
  )
}
