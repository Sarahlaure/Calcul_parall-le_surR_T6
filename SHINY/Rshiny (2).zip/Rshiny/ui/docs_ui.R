docs_ui <- function() {
  div(class = "custom-panel",
      h1("En savoir plus", class = "main-title"),
      br(),
      
      # Boutons de navigation
      fluidRow(
        column(3, actionButton("btn_data_doc", "📊 Données", class = "btn-primary")),
        column(3, actionButton("btn_var_doc", "🔍 Variables", class = "btn-primary")),
        column(3,actionButton("btn_methodo", "🧪 Méthodologie", class = "btn-primary")),
        column(3, actionButton("btn_about_doc", "👥 À propos", class = "btn-primary"))
      ),
      br(), br(),
      
      uiOutput("docs_content")
  )
}
