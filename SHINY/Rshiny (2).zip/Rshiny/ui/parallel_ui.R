
parallel_ui <- function() {
  div(
    class = "custom-panel",
    
    h1("Parallélisme et Performance", class = "main-title"),
    
    h4("🛳️ Calcul individuel (Paramétrage / Résultats)", class = "sub-title"),
    textOutput("perf_indiv_seq"),
    textOutput("perf_indiv_par"),
    textOutput("perf_indiv_speedup"),
    br(),
    
    h4("📊 Calcul global (Statistiques Globales)", class = "sub-title"),
    textOutput("perf_global_seq"),
    textOutput("perf_global_par"),
    textOutput("perf_global_speedup"),
    
    br(),
    actionButton("run_benchmark", "Informations sur la performance", class = "btn-primary")
  )
}
