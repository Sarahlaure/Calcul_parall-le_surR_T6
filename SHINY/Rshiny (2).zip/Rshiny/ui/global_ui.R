


global_ui <- function() {
  div(
    class = "custom-panel",
    
    h1("Statistiques Globales par Navire", class = "main-title"),
    p("Ce tableau s'affichera après exécution du calcul parallèle."),
    
    sliderInput("n_threads_global", "Nombre de cœurs à utiliser :", min = 1, max = parallel::detectCores(), value = 2),
    
    actionButton("run_global_calc", "Lancer le calcul parallèle", class = "btn-primary"),
    
    br(), br(),
    
    dataTableOutput("global_stats_table")
  )
}

