library(shiny)
library(leaflet)
library(parallel)

# Importer les modules UI
source("./ui/home_ui.R")
source("./ui/param_ui.R")
source("./ui/results_ui.R")
source("./ui/parallel_ui.R")
source("./ui/global_ui.R")
source("./ui/docs_ui.R")

# Importer les modules server
source("./server/home_server.R")
source("./server/param_server.R")
source("./server/results_server.R")
source("./server/parallel_server.R")
source("./server/global_server.R")
source("./server/docs_server.R")

# Chargement des données
ships_data <- read.csv("./ships/ships.csv")

ui <- fluidPage(
  tags$head(
    tags$style(HTML("
      body {
        background: linear-gradient(to bottom right, #e0f7fa, #b2ebf2, #80deea);
        font-family: 'Segoe UI', sans-serif;
        color: #2c3e50;
      }
      .sidebar {
        background-color: #01579b;
        height: 100vh;
        padding: 20px;
        position: fixed;
        width: 240px;
        color: white;
      }
      .sidebar h4 {
        text-align: center;
        margin-bottom: 30px;
        font-weight: bold;
        font-size: 20px;
      }
      .sidebar .btn {
        width: 100%;
        margin-bottom: 15px;
        font-size: 16px;
        font-weight: bold;
        color: #01579b !important;
        background-color: white;
        border: none;
        border-radius: 8px;
        text-align: left;
        padding-left: 20px;
      }
      .sidebar .btn:hover {
        background-color: #b3e5fc !important;
      }
      .main-content {
        margin-left: 260px;
        padding: 30px;
      }
      body {
        background: linear-gradient(to bottom right, #e0f7fa, #b2ebf2, #80deea);
        font-family: 'Segoe UI', sans-serif;
        color: #2c3e50;
      }

      .main-title {
        text-align: center;
        font-size: 50px;
        font-weight: bold;
        margin-top: 20px;
        margin-bottom: 30px;
        color: #01579b;
        text-shadow: 1px 1px 2px #bbdefb;
      }

      .sub-title {
        text-align: center;
        font-size: 24px;
        margin-bottom: 15px;
        color: #0277bd;
      }

      .custom-panel {
        background-color: rgba(255, 255, 255, 0.95);
        border-radius: 15px;
        padding: 30px;
        box-shadow: 0 0 25px rgba(0,0,0,0.1);
        max-width: 950px;
        margin: auto;
      }

      .btn-primary {
        background-color: #0288d1;
        border-color: #0288d1;
        font-size: 16px;
        padding: 10px 18px;
        border-radius: 8px;
        margin-top: 20px;
      }

      .btn-primary:hover {
        background-color: #0277bd;
        border-color: #0277bd;
      }
      ul {
      list-style-position: inside;
      text-align: center;
      padding-left: 0;
    }
    ul li {
      margin-bottom: 8px;
    }
    "))
  ),
  
  fluidRow(
    column(3, class = "sidebar",
           # ✅ Image de bannière/logo en haut de la barre latérale
           tags$img(src = "img1.png", height = "80px", style = "display: block; margin: 0 auto 20px auto;"),
           
           h4("Navigation"),
           actionButton("go_home", "\U0001F3E0 Accueil", class = "btn"),
           actionButton("go_select", "\u2699\ufe0f Paramétrage", class = "btn"),
           actionButton("go_results", "\U0001F4CD Résultats", class = "btn"),
           actionButton("go_global", "\U0001F4CA Stats Globales", class = "btn"),
           actionButton("go_parallel", "\U0001F680 Parallélisme", class = "btn"),
           actionButton("go_docs", "\U0001F4D8 À propos", class = "btn")
    ),
    column(9, class = "main-content",
           uiOutput("main_ui")
    )
  )
)

server <- function(input, output, session) {
  
  # Page courante
  current_page <- reactiveVal("home")
  
  # Gestion navigation
  observeEvent(input$go_home,     { current_page("home") })
  observeEvent(input$go_select,   { current_page("select") })
  observeEvent(input$go_results,  { current_page("results") })
  observeEvent(input$go_parallel, { current_page("parallel") })
  observeEvent(input$go_docs,     { current_page("docs") })
  observeEvent(input$go_global,     { current_page("global") })
  
  # Interface dynamique
  output$main_ui <- renderUI({
    switch(current_page(),
           "home"     = home_ui(),
           "select" = param_ui(ships_data),
           "results" = results_ui(),
           "parallel" = parallel_ui(),
           "global" = global_ui(),
           "docs" = docs_ui()
           
           
    )
  })
  
  # Lancer les serveurs
  home_server(input, output, session)
  param_server(input, output, session, ships_data)
  results_server(input, output, session, ships_data)
  parallel_server(input, output, session, ships_data)
  global_server(input, output, session, ships_data)
  docs_server(input, output, session, ships_data)
}

shinyApp(ui = ui, server = server)
