
home_server <- function(input, output, session) {
  output$doc_button <- downloadHandler(
    filename = function() { "documentation.pdf" },
    content = function(file) {
      file.copy("www/documentation.pdf", file)
    }
  )
}

