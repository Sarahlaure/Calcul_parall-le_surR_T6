
library(dplyr)
library(parallel)
library(DT)

ships_data <- read.csv("../ships/ships.csv")

global_server <- function(input, output, session, ships_data) {
  
  observeEvent(input$run_global_calc, {
    
    # Diviser les données par type de navire
    ship_list <- split(ships_data, ships_data$SHIPNAME)
    
    # Lancer le cluster
    cl <- makeCluster(input$n_threads_global)
    clusterExport(cl, varlist = c("ship_list"), envir = environment())
    
    # Calcul parallèle : vitesse moyenne, nombre de points, durée d'observation
    result <- parLapply(cl, ship_list, function(df) {
      df$DATETIME <- as.POSIXct(df$DATETIME)
      list(
        SHIPNAME = unique(df$SHIPNAME),
        ship_type = unique(df$ship_type),
        nb_points = nrow(df),
        vitesse_moy = round(mean(df$SPEED, na.rm = TRUE), 2),
        duree_obs = round(as.numeric(difftime(max(df$DATETIME), min(df$DATETIME), units = "hours")), 2)
      )
    })
    
    stopCluster(cl)
    
    # Transformer les résultats en data.frame
    df_result <- do.call(rbind, lapply(result, as.data.frame))
    
    # Afficher dans un tableau
    output$global_stats_table <- renderDataTable({
      datatable(
        df_result,
        rownames = FALSE,
        options = list(pageLength = 10),
        caption = htmltools::tags$caption("Tableau : Statistiques agrégées par navire")
      )
    })
  })
}
