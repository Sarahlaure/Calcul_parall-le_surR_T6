
library(future)
library(dplyr)
library(geosphere)

ships_data <- read.csv("../ships/ships.csv")

compute_max_successive_distance <- function(df) {
  df <- df[!is.na(df$LAT) & !is.na(df$LON) & !is.na(df$DATETIME) & !is.na(df$SPEED), ]
  df <- df[order(as.POSIXct(df$DATETIME)), ]
  
  if (nrow(df) >= 2) {
    coords <- df[, c("LON", "LAT")]
    distances <- geosphere::distHaversine(coords[-nrow(coords), ], coords[-1, ])
    idx_max <- which(distances == max(distances, na.rm = TRUE))
    idx_final <- tail(idx_max, 1)
    
    list(
      distance_km = round(distances[idx_final] / 1000, 2),
      departure_time = df$DATETIME[idx_final],
      arrival_time = df$DATETIME[idx_final + 1],
      mean_speed = round(mean(df$SPEED, na.rm = TRUE), 2)
    )
  } else {
    list(
      distance_km = NA,
      departure_time = NA,
      arrival_time = NA,
      mean_speed = NA
    )
  }
}


parallel_server <- function(input, output, session, ships_data) {
  
  observeEvent(input$run_benchmark, {
    
    n_threads <- ifelse(is.null(input$n_threads), 1, input$n_threads)
    
    ###### Données filtrées ######
    navire_test <- input$SHIPNAME
    data_navire <- ships_data[ships_data$SHIPNAME == navire_test, ]
    data_navire_clean <- data_navire[!is.na(data_navire$LAT) & !is.na(data_navire$LON) &
                                       !is.na(data_navire$DATETIME) & !is.na(data_navire$SPEED), ]
    data_navire_clean <- data_navire_clean[order(as.POSIXct(data_navire_clean$DATETIME)), ]
    
    ###### ⏱️ Temps SÉQUENTIEL ######
    start_seq <- Sys.time()
    res_seq <- compute_max_successive_distance(data_navire_clean)
    end_seq <- Sys.time()
    time_seq <- round(difftime(end_seq, start_seq, units = "secs"), 2)
    
    ###### ⚙️ Temps PARALLÈLE (même fonction appelée en future::future) ######
    library(future)
    plan(multisession, workers = n_threads)
    
    start_par <- Sys.time()
    res_par_future <- future::future({
      compute_max_successive_distance(data_navire_clean)
    })
    res_par <- value(res_par_future)
    end_par <- Sys.time()
    time_par <- round(difftime(end_par, start_par, units = "secs"), 2)
    ###### 4. AFFICHAGE PERFORMANCES INDIVIDUELLES ######
    output$perf_indiv_seq <- renderText({
      paste("⏱️ Temps séquentiel (résultats complets) :", time_seq, "s")
    })
    
    output$perf_indiv_par <- renderText({
      if (!is.na(time_par)) {
        paste("⚙️ Temps parallèle (résultats divisés) :", time_par, "s")
      } else {
        "⚙️ Temps parallèle non effectué"
      }
    })
    
    output$perf_indiv_speedup <- renderText({
      if (!is.na(time_par) && time_par > 0) {
        paste("⚡ Speedup :", round(as.numeric(time_seq) / as.numeric(time_par), 2),
              "(rapport entre le temps séquentiel et le temps parallèle)")
      } else {
        "⚠️ Speedup non disponible"
      }
    })
    
    output$max_parallel_result <- renderText({
      if (!is.na(max_par)) {
        paste("📏 Distance maximale (parallèle) :", max_par, "km")
      } else {
        "📏 Résultat parallèle non disponible"
      }
    })
    
    ###### 5. CALCUL GLOBAL : Moyenne des vitesses par navire ######
    t5 <- Sys.time()
    dummy <- ships_data %>%
      group_by(SHIPNAME) %>%
      summarise(moy_vitesse = mean(SPEED, na.rm = TRUE), .groups = "drop")
    t6 <- Sys.time()
    time_seq_global <- round(difftime(t6, t5, units = "secs"), 2)
    cl2 <- makeCluster(n_threads)
    ship_list <- split(ships_data, ships_data$SHIPNAME)
    clusterExport(cl2, varlist = c("ship_list"), envir = environment())
    clusterEvalQ(cl2, library(geosphere))
    
    n_ships <- length(ship_list)
    n_threads_global <- min(n_threads, n_ships)
    
    t7 <- Sys.time()
    
    if (n_threads_global <= 1) {
      # Cas séquentiel si un seul thread ou peu de navires
      results_par_global <- lapply(ship_list, function(df) mean(df$SPEED, na.rm = TRUE))
    } else {
      # Diviser équitablement la liste en sous-listes
      ship_list_split <- split(ship_list, rep(1:n_threads_global, length.out = n_ships))
      
      # Chaque thread traite une sous-liste complète
      partial_results <- parLapply(cl2, ship_list_split, function(sublist) {
        sapply(sublist, function(df) mean(df$SPEED, na.rm = TRUE))
      })
      
      # Fusionner les résultats
      results_par_global <- unlist(partial_results)
    }
    
    t8 <- Sys.time()
    stopCluster(cl2)
    
    time_par_global <- round(difftime(t8, t7, units = "secs"), 2)
    

    ###### 6. AFFICHAGE PERFORMANCES GLOBALES ######
    output$perf_global_seq <- renderText({
      paste("⏱️ Temps séquentiel (statistiques globales) :", time_seq_global, "s")
    })
    
    output$perf_global_par <- renderText({
      paste("⚙️ Temps parallèle (statistiques globales) :", time_par_global, "s")
    })
    
    output$perf_global_speedup <- renderText({
      if (!is.na(time_par_global) && time_par_global > 0) {
        paste("⚡ Speedup :", round(as.numeric(time_seq_global) / as.numeric(time_par_global), 2),
              "(rapport entre le temps séquentiel et le temps parallèle)")
      } else {
        "⚠️ Speedup non disponible"
      }
    })
  })
}
