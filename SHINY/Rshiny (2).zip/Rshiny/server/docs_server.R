
ships_data <- read.csv("../ships/ships.csv")

docs_server <- function(input, output, session, ships_data) {
  
  current_tab <- reactiveVal("data")
  
  observeEvent(input$btn_data_doc, {
    current_tab("data")
  })
  
  observeEvent(input$btn_var_doc, {
    current_tab("var")
  })
  
  observeEvent(input$btn_methodo, {
    current_tab("method")
  })
  
  
  observeEvent(input$btn_about_doc, {
    current_tab("about")
  })
  
  output$docs_content <- renderUI({
    switch(current_tab(),
           
           # 🟦 Données
           "data" = {
             tagList(
               h3("📚 Description de la base"),
               p("La base contient les informations détaillées des trajectoires maritimes de plusieurs navires.C'est une base AIS de 3 102 887 observations et 20 variables.Les données AIS (pour Automatic Identification System, ou Système d’Identification Automatique en français) sont des données maritimes utilisées pour le suivi et la surveillance des navires. Elles sont essentielles pour la sécurité maritime, la gestion du trafic, la recherche scientifique, et de plus en plus pour des analyses en économie maritime, environnement, pêche, etc. Elles se divisent en données dynamiques (position GPS, vitesse, cap, taux de rotation, état de navigation) et données statiques et de voyage (nom du navire, numéro MMSI, type de navire, dimensions, port de destination, etc.). Les données AIS sont reçues par différentes sources, principalement les stations terrestres et les satellites AIS. Les stations terrestres captent les signaux AIS des navires proches des côtes, avec une portée allant généralement jusqu'à 40-50 km. Ces stations sont souvent installées dans les ports ou sur des points élevés le long des côtes pour assurer une couverture optimale. Les satellites AIS, quant à eux, permettent de suivre les navires en haute mer, loin des côtes, et offrent une couverture globale. Cela permet de collecter des données AIS même dans les zones où il n'y a pas de stations terrestres disponibles."),
             )
           },
           
           # 🟦 Variables
           "var" = {
             var_choices <- names(ships_data)
             tagList(
               h3("📌 Détails sur une variable"),
               selectInput("selected_variable", "Choisir une variable :", choices = var_choices),
               verbatimTextOutput("var_description")
             )
           },
           
           #🟦 Méthodologie
           "method" = {
             tagList(
               h3("🧪 Méthodologie de l'application"),
               p("L’application met en œuvre une chaîne de traitement de données pour l’analyse du trafic maritime, avec un accent particulier sur le calcul parallèle sous R. Voici la méthodologie technique suivie :"),
               
               tags$ol(
                 tags$li(tags$b("1. Chargement et prétraitement :"),
                         " La base `ships.csv` est chargée au démarrage de l’application. Les colonnes clés telles que LAT, LON, DATETIME, SPEED sont nettoyées (gestion des NA, tri temporel)."),
                 
                 tags$li(tags$b("2. Sélection d’un navire :"),
                         " L’utilisateur choisit un navire dans la liste déroulante. Les données de ce navire sont extraites et ordonnées par DATETIME."),
                 
                 tags$li(tags$b("3. Calculs suivant un navire sélectionné :"),
                         " - Distance maximale entre deux observations consécutives : calculée via la fonction `distHaversine` (géosphère).",
                         tags$br(),
                         " - Heures de départ et d’arrivée correspondant à cette distance.",
                         tags$br(),
                         " - Vitesse moyenne du navire sur l’ensemble des observations."),
                 
                 tags$li(tags$b("4. Visualisation :"),
                         " Une carte Leaflet affiche le trajet maximal avec des marqueurs interactifs. Un résumé textuel est généré avec les résultats."),
                 
                 tags$li(tags$b("5. Benchmark calcul parallèle :"),
                         " Utilisation de `makeCluster` et `parLapply` pour comparer le temps d’exécution du même calcul (distance max, moyenne) entre version séquentielle et parallèle.",
                         tags$br(),
                         " Les données sont divisées dynamiquement selon le nombre de threads disponibles et la taille des sous-ensembles."),
                 
                 tags$li(tags$b("6. Statistiques globales parallélisées :"),
                         " Le calcul des vitesses moyennes par navire (`group_by(SHIPNAME)`) est réparti sur plusieurs cœurs via une stratégie de découpage de la liste des navires."),
                 
                 tags$li(tags$b("7. Affichage dynamique des performances :"),
                         " Le temps d’exécution est capturé avec `Sys.time()`. Le speedup est calculé comme le ratio : temps_séquentiel / temps_parallèle.")
               )
               )},
           
           
           # 🟦 À propos
           "about" = {
             tagList(
               p("Ce projet a été réalisé par deux élèves ingénieurs en statistique et économie à l'Ecole nationale de la Statistique et de l'Analyse économique à Dakar. 
    Cette application permettant de mettre en œuvre le calcul parallèle a été développée dans le cadre de notre cours de Projet statistique sur R sous l'encadrement de M. Aboubacar HEMA."),
               
               h3("👥 Projet réalisé par"),
               
               fluidRow(
                 column(6,
                        tags$div(style = "text-align: center;",
                                 tags$img(src = "elev1.jpg", width = "150px", style = "border-radius: 8px; margin-bottom: 10px;"),
                                 p(strong(" DIALLO Aissatou Sega"), br(),
                                   "Étudiante à l'ENSAE en ISE1 option économie")
                        )
                 ),
                 column(6,
                        tags$div(style = "text-align: center;",
                                 tags$img(src = "elev2.jpg", width = "150px", style = "border-radius: 8px; margin-bottom: 10px;"),
                                 p(strong("Élève 2 : FOGWOUNG Sarah Laure Djoufack"), br(),
                                   "Étudiante à l'ENSAE en ISE1 cycle long")
                        )
                 )
               )
             )
           }
    )
  })
  
  # Description dynamique selon la variable sélectionnée
  output$var_description <- renderPrint({
    req(input$selected_variable)
    var <- input$selected_variable
    vec <- ships_data[[var]]
    
    description <- switch(var,
                          "LAT"          = "Latitude géographique du navire.",
                          "LON"          = "Longitude géographique du navire.",
                          "SPEED"        = "Vitesse instantanée du navire (en nœuds).",
                          "COURSE"       = "Cap suivi par le navire (en degrés).",
                          "HEADING"      = "Direction vers laquelle le navire est orienté.",
                          "DESTINATION"  = "Port ou zone de destination prévue.",
                          "FLAG"         = "Pavillon du navire (pays d’enregistrement).",
                          "LENGTH"       = "Longueur du navire (en mètres).",
                          "SHIPNAME"     = "Nom du navire.",
                          "SHIPTYPE"     = "Code numérique du type de navire.",
                          "SHIP_ID"      = "Identifiant unique du navire.",
                          "WIDTH"        = "Largeur du navire (en mètres).",
                          "DWT"          = "Port en lourd (deadweight tonnage), en tonnes.",
                          "DATETIME"     = "Date et heure de l’observation.",
                          "PORT"         = "Port d’enregistrement ou de stationnement.",
                          "date"         = "Date (extrait de DATETIME).",
                          "week_nb"      = "Numéro de semaine (selon la date d’observation).",
                          "ship_type"    = "Catégorie du navire (ex : Cargo, Tanker, etc.).",
                          "port"         = "Port assigné (nettoyé ou transformé).",
                          "is_parked"    = "Indique si le navire est stationné (TRUE/FALSE).",
                          "Aucune description disponible pour cette variable."
    )
    
    cat("🛈 Description : ", description, "\n\n")
    
    if (is.numeric(vec)) {
      cat("📊 Statistiques :\n")
      print(summary(vec))
      
    } else if (is.factor(vec) || is.character(vec)) {
      cat("📋 Modalités principales (en %):\n")
      
      freq_table <- sort(prop.table(table(vec)), decreasing = TRUE) * 100
      freq_top <- head(freq_table, 10)
      
      print(round(freq_top, 2))
      
    } else {
      cat("🔎 Type non reconnu.")
    }
  })
}
