
ships_data <- read.csv("../ships/ships.csv")

param_server <- function(input, output, session, ships_data) {
  
  # Afficher dynamiquement les navires selon le type choisi
  output$ship_selector <- renderUI({
    req(input$ship_type)
    
    ships <- subset(ships_data, ship_type == input$ship_type)$SHIPNAME
    
    selectInput("ship_name", "Sélectionner un navire :", choices = unique(ships))
  })
  
  # Affichage du nombre de cœurs
  output$core_info <- renderText({
    paste("Cœurs disponibles sur la machine :", detectCores())
  })
  
  # Lors du clic sur "Lancer l’analyse"
  observeEvent(input$run_analysis, {
    showModal(modalDialog(
      title = "Lancement de l'Analyse",
      paste("Analyse du navire", input$ship_name, "avec", input$n_threads, "threads."),
      easyClose = TRUE,
      footer = NULL
    ))
    
    # Traitement réel à ajouter ici
  })
}
