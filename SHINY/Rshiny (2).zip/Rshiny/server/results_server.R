
library(dplyr)
library(leaflet)
library(geosphere)
library(future)
library(promises)

results_server <- function(input, output, session, ships_data) {
  
  # Mise à jour du plan en fonction du nombre de cœurs choisis
  observeEvent(input$n_threads, {
    # S'assurer que le nombre est valide et planifier
    workers <- ifelse(is.null(input$n_threads) || input$n_threads < 1, 1, input$n_threads)
    plan(multisession, workers = workers)
  })
  
  # Données filtrées selon le navire sélectionné
  filtered_data <- reactive({
    req(input$ship_name)
    
    data <- ships_data[ships_data$SHIPNAME == input$ship_name, ]
    data <- data[!is.na(data$LAT) & !is.na(data$LON) & !is.na(data$DATETIME) & !is.na(data$SPEED), ]
    data <- data[order(as.POSIXct(data$DATETIME)), ]
    
    data
  })
  
  result_data <- reactiveVal(NULL)
  
  # Analyse lancée
  observeEvent(input$run_analysis, {
    data <- filtered_data()
    req(nrow(data) >= 2)
    
    # Calcul parallèle avec future
    future({
      coords <- data[, c("LON", "LAT")]
      distances <- geosphere::distHaversine(coords[-nrow(coords), ], coords[-1, ])
      idx_max <- which(distances == max(distances, na.rm = TRUE))
      idx_final <- tail(idx_max, 1)
      
      list(
        from = list(lat = data$LAT[idx_final], lon = data$LON[idx_final], time = data$DATETIME[idx_final]),
        to   = list(lat = data$LAT[idx_final + 1], lon = data$LON[idx_final + 1], time = data$DATETIME[idx_final + 1]),
        distance_km = round(distances[idx_final] / 1000, 2),
        speed_avg = round(mean(data$SPEED, na.rm = TRUE), 2)
      )
    }) %...>% result_data()
    
  })
  
  # Affichage de la carte
  output$map <- renderLeaflet({
    res <- result_data()
    req(!is.null(res))
    req(!any(is.na(c(res$from$lon, res$from$lat, res$to$lon, res$to$lat))))
    
    leaflet() |>
      addTiles() |>
      addMarkers(lng = res$from$lon, lat = res$from$lat, popup = "Départ") |>
      addMarkers(lng = res$to$lon, lat = res$to$lat, popup = "Arrivée") |>
      addPolylines(
        lng = c(res$from$lon, res$to$lon),
        lat = c(res$from$lat, res$to$lat),
        color = "blue", weight = 3
      )
  })
  
  
  # Affichage résumé textuel
  output$summary <- renderText({
    req(result_data())
    res <- result_data()
    paste0(
      "📏 Distance maximale entre deux points successifs : ", res$distance_km, " km\n",
      "🕒 Heure de départ : ", res$to$time, "\n",
      "🕓 Heure d’arrivée : ", res$from$time, "\n",
      "🚀 Vitesse moyenne : ", res$speed_avg, " nœuds"
    )
  })
}
